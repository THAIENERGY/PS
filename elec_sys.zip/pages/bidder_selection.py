from dash import html, dcc
import dash
import glob
import pickle as pkl
import pandas as pd
import numpy as np
import display_util as util

dash.register_page(__name__)

TARGET = 1000
HEADERS = {'selected':'รับข้อเสนอ', 'bidder': 'รายที่', 'reduced_wattage': 'Offered reduction (kW)', 'price_per_watt': 'Offered Price (Baht/kW)'}
ALIGNMENT = {'selected': 'center', 'bidder': 'center', 'reduced_wattage': 'right', 'price_per_watt': 'right'}
FORMATS = {'reduced_wattage': 'num', 'price_per_watt': 'num'}

def read_data():
    files = glob.glob('./auctions/*.pkl')
    data = []
    for file in files:
        with open(file, 'rb') as f:
            row = pkl.load(f)
        data.append(row)

    df = pd.DataFrame(data, columns=['bidder', 'reduced_wattage', 'price_per_watt'])
    df = df.sort_values(['price_per_watt', 'reduced_wattage'], ascending=[True, False]).reset_index(
        drop=True).reset_index()
    df['index'] = df['index'] + 1
    df['cumsum'] = df['reduced_wattage'].cumsum()

    df['selected'] = df['cumsum'] <= TARGET

    if df[df['cumsum'] == TARGET].shape[0] == 0:
        for i, row in df.iterrows():
            if row['selected'] == False:
                break

        remainder = df.loc[i, 'cumsum'] - TARGET
        remainder_row = row.copy()
        remainder_row['index'] = remainder_row['index'] - 0.1
        remainder_row['reduced_wattage'] = remainder_row['reduced_wattage'] - remainder
        remainder_row['selected'] = True

        row['reduced_wattage'] = remainder
        row['cumsum'] = row['cumsum'] - remainder
        row['selected'] = False

    df = df[df['index'] != row['index']]
    df.loc[df.shape[0] + 1] = remainder_row
    df.loc[df.shape[0] + 1] = row
    df = df.sort_values('index')
    df.to_csv('./auctions/selected.csv', index=False)

    # remainder = TARGET - df.loc[i - 1, 'cumsum']
    #
    #     remainder_row = row.copy()
    #     remainder_row['index'] = remainder_row['index'] + 0.1
    #     remainder_row['reduced_wattage'] = remainder_row['reduced_wattage'] - remainder
    #
    #     row['reduced_wattage'] = remainder
    #     row['cumsum'] = row['cumsum'] - remainder
    #     row['selected'] = True
    #
    # df = df[df['index'] != row['index']]
    # df.loc[df.shape[0] + 1] = row
    # df.loc[df.shape[0] + 1] = remainder_row
    # df = df.sort_values('index')
    # df.to_csv('./auctions/selected.csv', index=False)

    return df


def load_layout():
    df_result = read_data()
    df_result['selected'] = np.where(df_result['selected'], 'Y', 'N')
    df_result = util.format_table(df_result, FORMATS)
    df_result = df_result[['selected', 'bidder', 'reduced_wattage', 'price_per_watt']]

    return html.Div([
        html.Div([dcc.Link('Back', href='/auction-result',
                           style={'color': '#bed4c4', 'font-family': 'serif', 'font-weight': 'bold',
                                  "text-decoration": "none", 'font-size': '20px'}),
                  dcc.Link('Next', href='/evaluation',
                           style={'color': '#bed4c4', 'font-family': 'serif', 'font-weight': 'bold',
                                  "text-decoration": "none", 'font-size': '20px', 'padding-left': '80%'})],
                 style={'padding-top': '10px'}),
        html.Div([html.H1('รายชื่อผู้ประมูลที่เข้าเกณฑ์การประมูลลดไฟฟ้า 1,000 kW'),
                  html.P('ผู้ที่ถูกรับเข้าข้อเสนอจะได้รับอีเมลตอบรับข้อเสนอ ทางการไฟฟ้าจะดำเนินการติดตามผลต่อไปเพื่อจ่ายผลตอบแทนตามปริมาณไฟฟ้าที่ลดได้'),
                  # html.Ul([dcc.Checklist(
                  #     ['Factory {:>6} ลด {} kW ราคาต่อ kW อยู่ที่ {} บาท'.format(row['bidder'], row['reduced_wattage'],
                  #                                                             row['price_per_watt']) for i, row in
                  #      df_result.iterrows()],
                  #     ['Factory {:>6} ลด {} kW ราคาต่อ kW อยู่ที่ {} บาท'.format(row['bidder'], row['reduced_wattage'],
                  #                                                             row['price_per_watt']) for i, row in
                  #      df_result.iterrows() if row['selected']],
                  #     inline=True,
                  #     labelStyle={'display': 'block'},
                  #     style={"width": 400, "overflow": "auto"})
                  # ]),
                  util.generate_table(df_result, HEADERS, ALIGNMENT)], style={'padding-left': '10%', 'padding-right': '10%'})
    ])


layout = load_layout
