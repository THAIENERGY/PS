from dash import html, dcc, callback
import dash
from dash.dependencies import Output, Input, State
import pickle as pkl
import glob
import pandas as pd
import plotly.express as px
import display_util as util

dash.register_page(__name__)

HEADERS = {'index': 'ลำดับที่', 'reduced_wattage': 'เสนอจะลด (kW)', 'price_per_watt': 'บาท/kW'}
ALIGNMENT = {'index': 'left', 'reduced_wattage': 'right', 'price_per_watt': 'right'}
FORMATS = {'reduced_wattage': 'num', 'price_per_watt': 'num'}


def read_data():
    files = glob.glob('./auctions/*.pkl')
    data = []
    for file in files:
        with open(file, 'rb') as f:
            row = pkl.load(f)
        data.append(row)

    df = pd.DataFrame(data, columns=['bidder', 'reduced_wattage', 'price_per_watt'])
    df = df.sort_values(['price_per_watt', 'reduced_wattage'], ascending=[True, False]).reset_index(
        drop=True).reset_index()
    df['index'] = df['index'] + 1
    df = df[['index', 'reduced_wattage', 'price_per_watt']]

    return df


def load_layout():
    df = read_data()

    df_temp = df.copy()
    df_temp['cumsum'] = df_temp['reduced_wattage'].cumsum()
    df_temp = pd.concat([df_temp, df_temp]).sort_values('index')
    df_temp['cumsum'] = df_temp['cumsum'].shift(1).fillna(0)
    df = util.format_table(df, FORMATS)

    fig = px.line(df_temp, x='cumsum', y='price_per_watt')
    fig.update_layout(xaxis_title='Accumulated Negative Power(kW)',
                      yaxis_title='Price(THB/kW)')
    fig.add_vline(x=1000, line_dash="dash")

    return html.Div([
        html.Div(
            [dcc.Link('Back', href='/auction', style={'color': '#bed4c4', 'font-family': 'serif', 'font-weight': 'bold',
                                                      "text-decoration": "none", 'font-size': '20px'}),
             dcc.Link('Next', href='/bidder-selection',
                      style={'color': '#bed4c4', 'font-family': 'serif', 'font-weight': 'bold',
                             "text-decoration": "none", 'font-size': '20px', 'padding-left': '80%'})],
            style={'padding-top': '10px'}),
        html.Div([html.H1(children='ผลการประมูลลดความต้องการไฟฟ้า'),
                  html.Div(util.generate_table(df, HEADERS, ALIGNMENT), style={'float': 'left'}),
                  dcc.Graph(id='cumsum', figure=fig, style={'float': 'right', 'width':'1100px'})], style={'padding-left': '10%', 'padding-right': '10%'})

    ])


layout = load_layout
