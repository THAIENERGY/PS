from dash import html
import numpy as np

def generate_table(dataframe, headers, alignment, deactivate=False, summary=False):
    if deactivate:
        header_class = '_deact'
    else:
        header_class = ''
    n = dataframe.shape[0]
    return html.Table([
        html.Thead(
            html.Tr([html.Th(headers[col]) for col in dataframe.columns], className='table_header{}'.format(header_class))
        ),
        html.Tbody([
            html.Tr([
                html.Td(dataframe.iloc[i][col], style={'text-align':alignment[col]}) for col in dataframe.columns],
                className='table_body{}'.format(header_class)) for i in range(n-summary)
        ] + [html.Tr([
                html.Td(dataframe.iloc[n-1][col], style={'text-align':alignment[col]}, className='table_summary') for col in dataframe.columns
            ], className='table_summary') for _ in range(summary)
        ])
    ])


def format_table(df, formats):
    for column, format in formats.items():
        if column in df.columns:
            if format in ['%', 'percentage']:
                df[column] = np.where(df[column].isnull(), '', (df[column] * 100).map('{:,.2f} %'.format))
            elif format in ['num', 'number']:
                df[column] = np.where(df[column].isnull(), '', df[column].map('{:,.2f}'.format))

    return df
