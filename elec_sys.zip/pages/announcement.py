import dash
from dash import html, dcc
import base64

# Load the logo image and encode it in base64 format
with open('electricity-logo-design-abstract-electric-logo_219523-97.webp', 'rb') as f:
    logo_b64 = base64.b64encode(f.read()).decode('ascii')

dash.register_page(__name__, path='/')

# Create the layout of the first page
layout = html.Div([
    html.Div(dcc.Link('Next', href='/auction', style={'color': '#bed4c4', 'font-family': 'serif', 'font-weight': 'bold',
                                                      "text-decoration": "none", 'font-size': '20px'}),
             style={'padding-left': '80%', 'padding-top': '10px'}),
    # Display the logo in the center of the page
    html.Img(src='data:image/png;base64,{}'.format(logo_b64), style={'display': 'block', 'margin': 'auto'},
             width=200, height=200),
    # Add some text below the logo
    html.Div([html.H1('ประกาศจากการไฟฟ้า', style={'text-align':'center', 'color': '#FF3333'}),
        html.P('ขณะนี้การไฟฟ้าเริ่มการประมูลลดการใช้ไฟฟ้าประจำเดือนกุมภาพันธ์แล้ว โดยการไฟฟ้าฯ มีความต้องการลดไฟฟ้าลงอยู่ที่ 1,000 กิโลวัตต์ ขอให้ผู้ที่มีความประสงค์จะยื่นประมูลสามารถเข้าสู่ระบบประมูลและแจ้งปริมาณไฟฟ้าที่ต้องการลดรวมถึงราคาต่อหน่วยได้ทันที ผลการประมูลจะประกาศภายในวันที่ 25 มกราคม 2566 เป็นต้นไป',
               style={'font-size': '20px'})],
             style={'padding-left': '20%', 'padding-right': '20%', 'padding-top': '10px'})


])
