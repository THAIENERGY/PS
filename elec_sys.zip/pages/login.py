from dash import Dash, html, dcc, callback
from dash.dependencies import Input, Output, State
import dash

dash.register_page(__name__)

layout = html.Div([
    dcc.Location(id='url', refresh=False),
    html.H1('Login'),
    html.Label('Username:'),
    html.Br(),
    dcc.Input(type='text', id='username'),
    html.Br(),
    html.Label('Password:'),
    html.Br(),
    dcc.Input(type='password', id='password'),
    html.Br(),
    html.Button('Submit', id='button'),
    html.Div(id='output')
])

@callback(
    Output('output', 'children'),
    Input('button', 'n_clicks'),
    State('username', 'value'),
    State('password', 'value'))
def update_output(n_clicks, username, password):
    if n_clicks is None:
        return ''
    if username == 'admin' and password == 'secret':
        return 'Logged in successfully'
    return 'Invalid login credentials'