from dash import html, dcc, callback
import dash
from dash.dependencies import Output, Input, State
import pickle as pkl
import datetime as dt
import plotly.graph_objs as go
import plotly.express as px
import pandas as pd

dash.register_page(__name__)

# layout = html.Div(children=[
#     html.Div([dcc.Link('Back', href='/', style={'color': '#bed4c4', 'font-family': 'serif', 'font-weight': 'bold',
#                                                 "text-decoration": "none", 'font-size': '20px'}),
#               dcc.Link('Next', href='/auction-result',
#                        style={'color': '#bed4c4', 'font-family': 'serif', 'font-weight': 'bold',
#                               "text-decoration": "none", 'font-size': '20px', 'padding-left': '80%'})],
#              style={'padding-top': '10px'}),
#     html.Div([html.H1('การประมูลลดความต้องการไฟฟ้า'),
#               dcc.Dropdown(id='bidder-dropdown',
#                            options=[{'label': 'Factory {}'.format(i), 'value': i} for i in range(1, 11)],
#                            value='', style={'padding-right': '50%'}),
#               html.H2('นำเสนอการประมูล'),
#               html.Label('ปริมาณที่ต้องการลด:'),
#               dcc.Input(type='number', id='reduced_load'),
#               html.Label('kW'),
#               dcc.Input(type='hidden', id='reduced_load2'),
#               html.Br(), html.Label('ราคาต่อหน่วยที่ต้องการเสนอ:'),
#               dcc.Input(type='number', id='reduced_price'),
#               html.Label('บาท'),
#               dcc.Input(type='hidden', id='reduced_price2'),
#               html.Br(),
#               html.Div(id='summary', children='กรุณาระบุปริมาณที่ต้องการลดและราคาต่อหน่วยเพื่อเสนอประมูล'),
#               html.Button('Submit', id='submit_button')], style={'padding-left': '10%', 'padding-right': '10%'}),
#     dcc.Graph(id='reference')
# ])

layout = html.Div(children=[
    html.Div([dcc.Link('Back', href='/', style={'color': '#bed4c4', 'font-family': 'serif', 'font-weight': 'bold',
                                                "text-decoration": "none", 'font-size': '20px'}),
              dcc.Link('Next', href='/auction-result',
                       style={'color': '#bed4c4', 'font-family': 'serif', 'font-weight': 'bold',
                              "text-decoration": "none", 'font-size': '20px', 'padding-left': '80%'})],
             style={'padding-top': '10px'}),
    html.Div([html.H1('การประมูลลดความต้องการไฟฟ้า'),
              dcc.Dropdown(id='bidder-dropdown',
                           options=[{'label': 'Factory {}'.format(i), 'value': i} for i in range(1, 11)],
                           value='', style={'padding-right': '50%'}),
              html.H2('นำเสนอการประมูล'),
              html.Div([html.Label('ปริมาณที่ต้องการลด:'),
                        html.Br(),
                        html.Label('ราคาต่อหน่วยที่ต้องการเสนอ:')], style={'width': '20%', 'float': 'left'}),
              html.Div([dcc.Input(type='number', id='reduced_load'),
                        html.Label('kW'),
                        dcc.Input(type='hidden', id='reduced_load2'),
                        html.Br(),
                        dcc.Input(type='number', id='reduced_price'),
                        html.Label('บาท'),
                        dcc.Input(type='hidden', id='reduced_price2')], style={'width': '40%', 'float': 'left'}),
              html.Div(html.P(id='summary', children='กรุณาระบุปริมาณที่ต้องการลดและราคาต่อหน่วยเพื่อเสนอประมูล', style={'width': '40%', 'float': 'buttom'})),
              html.Button('Submit', id='submit_button', style={'font-size': '20px'})], style={'padding-left': '10%', 'padding-right': '10%'}),
    dcc.Graph(id='reference')
])

df_ref = pd.read_excel('./reference/reference_actual.xlsx')
df_ref = df_ref.drop(columns=df_ref.columns[1])
df_ref = df_ref.dropna()
df_ref = df_ref[df_ref['TIME'] != 'TIME']
df_ref = df_ref.rename(
    columns={col: col.time().strftime('%H:%M') if type(col) == dt.datetime else col.strftime('%H:%M') for col in
             df_ref.columns[1:]})


@callback(
    Output(component_id='summary', component_property='children'),
    Output(component_id='reduced_load2', component_property='value'),
    Output(component_id='reduced_price2', component_property='value'),
    Input(component_id='reduced_load', component_property='value'),
    Input(component_id='reduced_price', component_property='value')
)
def on_change(reduced_load, reduced_price):
    if type(reduced_load) in [float, int] and type(reduced_price) in [float, int]:
        return f'ยอดรวม {reduced_load * reduced_price:,.02f} บาท', reduced_load, reduced_price
    return f'กรุณาระบุปริมาณที่ต้องการลดและราคาต่อหน่วยเพื่อเสนอประมูล', None, None


@callback(
    Output(component_id='reduced_load', component_property='value'),
    Output(component_id='reduced_price', component_property='value'),
    Input(component_id='submit_button', component_property='n_clicks'),
    State(component_id='bidder-dropdown', component_property='value'),
    State(component_id='reduced_load2', component_property='value'),
    State(component_id='reduced_price2', component_property='value')
)
def on_submit(n_clicks, bidder, reduced_load2, reduced_price2):
    if bidder != '' and type(reduced_load2) in [float, int] and type(reduced_price2) in [float, int]:
        file = str(bidder).lower().replace(' ', '_')
        with open(f'./auctions/{file}.pkl', 'wb') as f:
            pkl.dump((bidder, reduced_load2, reduced_price2), f)
        return None, None
    else:
        return reduced_load2, reduced_price2


@callback(
    Output('reference', 'figure'),
    Input('bidder-dropdown', 'value'))
def update_graph(bidder):
    if type(bidder) == str or bidder is None:
        data = ['{:02d}:{:02d}'.format(h, m * 15) for h in range(24) for m in range(4)]
        fig = go.Figure(go.Scatter(x=data,
                                   y=[0 for _ in range(len(data))]))
        fig.update_layout(xaxis_title='', yaxis_title='kW')
        fig.update_layout(yaxis_range=[0, 5000])
        fig.add_vline(x='09:00', line_dash="dash")
        fig.add_vline(x='16:00', line_dash="dash")
    else:
        data = df_ref[df_ref['TIME'] == f'R{bidder}'].T.iloc[1:, 0]
        data = data.reset_index()

        v_max = data[data.columns[1]].max()

        fig = px.line(data, x='index', y=data.columns[1])
        fig.add_hline(y=v_max, line_dash="dash")
        fig.add_vline(x='09:00', line_dash="dash")
        fig.add_vline(x='16:00', line_dash="dash")
        fig.update_layout(xaxis_title='', yaxis_title='kW')

    return fig
