from dash import html, dcc
import dash
import numpy as np
import pandas as pd
import glob
import pickle as pkl
import datetime as dt
import display_util as util

dash.register_page(__name__)
HEADERS = {'bidder': 'รายที่', 'price_per_watt': 'Offered Price (Baht/kW)', 'reduced_wattage': 'Offered reduction (kW)',
           'diff': 'Actual Reduction (kW)', 'reduced_percentage': '% of offered reduction',
           'actual_amount': 'Price (Baht/kW)', 'amount_paid': 'Amounts paid (Baht)'}
ALIGNMENT = {'bidder': 'center', 'price_per_watt': 'right', 'reduced_wattage': 'right', 'diff': 'right',
             'reduced_percentage': 'right', 'actual_amount': 'right', 'amount_paid': 'right'}
FORMATS = {'price_per_watt': 'num', 'reduced_wattage': 'num', 'diff': 'num', 'reduced_percentage': '%',
           'actual_amount': 'num', 'amount_paid': 'num'}


def transform_table(df):
    df = df.drop(columns=df.columns[1])
    df = df.dropna()
    df = df[df['TIME'] != 'TIME']
    df = df.rename(
        columns={col: col.time().strftime('%H:%M') if type(col) == dt.datetime else col.strftime('%H:%M') for col in
                 df.columns[1:]})
    df['peak'] = df.iloc[:, 1:].max(axis=1)

    return df


def read_data():
    data = pd.read_excel('./reference/reference_actual.xlsx', sheet_name=None)
    df_ref = data['Load profiles_Refences']
    df_ref = transform_table(df_ref)

    df_act = data['Load profiles_Actual']
    df_act = transform_table(df_act)
    df_act['diff'] = df_ref['peak'] - df_act['peak']
    df_act['diff'] = np.where(df_act['diff'] > 0, df_act['diff'], 0)
    df_act['TIME'] = df_act['TIME'].str.replace('R', '').astype(int)

    df = pd.read_csv('./auctions/selected.csv')
    df = df.merge(df_act, left_on='bidder', right_on='TIME', how='left')
    df['reduced_percentage'] = df['diff'] / df['reduced_wattage']
    df['level'] = np.where(df['reduced_percentage'] < 0.5, 0,
                           np.where(df['reduced_percentage'] < 0.75, 0.5,
                                    np.where(df['reduced_percentage'] < 1, 0.75,
                                             np.where(df['reduced_percentage'] <= 1.05, 1, 0))))
    df['actual_amount'] = df['level'] * df['price_per_watt']
    df['amount_paid'] = df['actual_amount'] * df['diff']
    df['bidder'] = 'Factory ' + df['bidder'].astype(str)
    df = df.fillna(0)
    df = df[df['selected']]
    df = df[['bidder', 'price_per_watt', 'reduced_wattage', 'diff', 'reduced_percentage', 'actual_amount',
             'amount_paid', 'selected']]

    df_sum = df.sum()

    for col in df_sum.index:
        if col not in ['diff', 'amount_paid']:
            df_sum.loc[col] = np.nan
    df_sum.loc['bidder'] = 'Total'
    df.loc[df.shape[0]] = df_sum
    df = util.format_table(df, FORMATS)

    df = df.drop(columns='selected')

    return df


def load_layout():
    df = read_data()

    contents = [['<50% ของปริมาณ Reduced demand ที่เสนอ', 'ไม่ได้รับผลตอบแทน'],
                ['50% ถึง <75% ของปริมาณ Reduced demand ที่เสนอ', '50% ของราคา Reduced demand ที่เสนอ'],
                ['75% ถึง <100% ของปริมาณ Reduced demand ที่เสนอ', '75% ของราคา Reduced demand ที่เสนอ'],
                ['100% ถึง 105% ของปริมาณ Reduced demand ที่เสนอ', 'เท่ากับราคา Reduced demand ที่เสนอ'],
                ['>105% ของปริมาณ Reduced demand ที่เสนอ', 'ไม่ได้รับผลตอบแทน']]
    contents = pd.DataFrame(contents, columns=['h1', 'h2'])
    content_headers = {'h1': 'ผลการดำเนินงานตอบสนองด้านโหลดของผู้ใช้ไฟฟ้า', 'h2': 'อัตราผลตอบแทน'}

    return html.Div([
        html.Div([dcc.Link('Back', href='/bidder-selection',
                           style={'color': '#bed4c4', 'font-family': 'serif', 'font-weight': 'bold',
                                  "text-decoration": "none", 'font-size': '20px'}),
                  dcc.Link('Home', href='/',
                           style={'color': '#bed4c4', 'font-family': 'serif', 'font-weight': 'bold',
                                  "text-decoration": "none", 'font-size': '20px', 'padding-left': '80%'})],
                 style={'padding-top': '10px'}),
        html.Div([html.H1('สรุปผลการลดการใช้ไฟฟ้าและค่าตอบแทนจริง'),
                  util.generate_table(df, HEADERS, ALIGNMENT, summary=True),
                  html.Div(style={'padding-top': '50px'}),
                  util.generate_table(contents, content_headers, {'h1': 'left', 'h2': 'left'}, deactivate=True)],
                 style={'padding-left': '10%', 'padding-right': '10%'})
    ])


layout = load_layout
